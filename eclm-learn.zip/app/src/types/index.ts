// ============================================
// ECLM: Emergent Construction Learning Model
// ============================================

export type CEFRLevel = 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2';
export const CEFR_ORDER: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];
export const CEFR_NUM: Record<CEFRLevel, number> = { A1: 1, A2: 2, B1: 3, B2: 4, C1: 5, C2: 6 };

/** A construction: form-meaning-usage triplet */
export interface Construction {
  id: string;
  form: string;           // Surface form template
  forms: string[];        // All surface variants
  meaning: string;        // Semantic function
  level: 'micro' | 'meso' | 'macro';
  cefr: CEFRLevel;
  domain: string[];       // Applicable topics
  register: 'formal' | 'academic' | 'neutral' | 'informal';
  isFormulaic: boolean;
  parents: string[];
  children: string[];
  peers: { id: string; relation: 'compete' | 'collocate' | 'intensify' }[];
  learnerDefault: string; // Simpler alternative learners use
}

/** 3D mastery: recognition, production, context width */
export interface Mastery3D {
  alpha: number;          // Recognition [0,1]
  beta: number;           // Production [0,1]
  gamma: number;          // Context width [0,inf)
  lastEncounter: number;  // timestamp
  encounterCount: number;
  contextsUsed: string[];
}

/** Student state */
export interface StudentState {
  mastery: Record<string, Mastery3D>;
  affect: AffectiveState;
  history: EncounterRecord[];
  currentFocus: string | null;
}

/** Affective state */
export interface AffectiveState {
  engagement: number;
  confusion: number;
  frustration: number;
  boredom: number;
  dominant: 'flow' | 'learning' | 'confused' | 'frustrated' | 'bored' | 'disengaged';
}

export type EncounterType = 'input' | 'elicit' | 'dialogical' | 'varied';

export interface EncounterRecord {
  timestamp: number;
  constructionId: string;
  type: EncounterType;
  contextId: string;
  mode: 'explicit' | 'implicit';
  result: 'recognized' | 'produced' | 'failed' | 'prompted';
  deltaAlpha: number;
  deltaBeta: number;
}

/** Material with construction annotations */
export interface Material {
  id: string;
  title: string;
  text: string;
  prompt?: string;
  constructions: MaterialConstruction[];
  topic: string;
  register: string;
  cefr: CEFRLevel;
  type: 'reading' | 'writing_prompt' | 'cloze' | 'free_response';
}

export interface MaterialConstruction {
  constructionId: string;
  spans: [number, number][];
}

/** LLM contrastive analysis result */
export interface ContrastiveAnalysis {
  constructionsUsed: UsedConstruction[];
  gaps: ConstructionGap[];
  overallLevel: string;
  suggestedFocus: string[];
}

export interface UsedConstruction {
  constructionId: string;
  text: string;        // The actual text the student wrote
  quality: 'correct' | 'partial' | 'awkward';
}

export interface ConstructionGap {
  constructionId: string;
  studentText: string;     // What they wrote instead
  targetForm: string;      // What they could have used
  gapType: 'missing' | 'suboptimal' | 'upgrade_opportunity';
  context: string;         // The sentence context
  inZPD: boolean;          // Is this within their learning zone?
}

/** Dialogue turn for construction implantation */
export interface DialogueTurn {
  role: 'tutor' | 'student';
  content: string;
  type?: 'explanation' | 'example' | 'prompt' | 'feedback' | 'celebration';
  targetConstruction?: string;
}

/** Scheduled learning item */
export interface ScheduledItem {
  material: Material;
  focusConstruction: string;
  purpose: 'first_exposure' | 'elicit_production' | 'varied_context' | 'free_use';
}
