import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { setLLMConfig, getPresets, getLLMConfig } from '@/engine/llm';
import { AlertCircle, CheckCircle, Info } from 'lucide-react';

interface Props { onDone: () => void; }

type PresetKey = 'openai' | 'kimi' | 'azure' | 'custom';

export default function ApiKeySetup({ onDone }: Props) {
  const current = getLLMConfig();
  const [preset, setPreset] = useState<PresetKey>('openai');
  const [apiKey, setApiKey] = useState(current.apiKey);
  const [baseUrl, setBaseUrl] = useState(current.baseUrl);
  const [model, setModel] = useState(current.model);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; msg: string } | null>(null);

  const presets = getPresets();

  const handlePresetChange = (key: PresetKey) => {
    setPreset(key);
    const p = presets[key];
    if (key !== 'custom') {
      setBaseUrl(p.baseUrl);
      setModel(p.model);
    }
    setTestResult(null);
  };

  const handleSave = () => {
    if (!apiKey.trim()) return;
    setLLMConfig({ apiKey: apiKey.trim(), baseUrl: baseUrl.trim(), model: model.trim() });
    onDone();
  };

  const handleTest = async () => {
    if (!apiKey.trim()) return;
    setTesting(true);
    setTestResult(null);
    try {
      setLLMConfig({ apiKey: apiKey.trim(), baseUrl: baseUrl.trim(), model: model.trim() });
      const { callLLMTest } = await import('@/engine/llm');
      const result = await callLLMTest();
      setTestResult({ ok: true, msg: `Connected! Response: "${result}"` });
    } catch (e) {
      const err = e as Error;
      // Check if proxy is not available (404 on /api/chat means not deployed to Vercel)
      if (err.message.includes('404') || err.message.includes('Unexpected')) {
        setTestResult({ ok: false, msg: 'Proxy not found at /api/chat. This app must be deployed to Vercel (or another platform that supports the /api/chat endpoint). See deployment guide below.' });
      } else {
        setTestResult({ ok: false, msg: err.message });
      }
    }
    setTesting(false);
  };

  const canSave = apiKey.trim().length > 0 && baseUrl.trim().length > 0 && model.trim().length > 0;

  return (
    <div className="max-w-lg mx-auto p-6 pt-10 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-xl">API Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Architecture note */}
          <div className="flex gap-2 bg-blue-50 border border-blue-200 rounded-md p-3 text-sm text-blue-800">
            <Info className="w-5 h-5 shrink-0" />
            <div>
              <p className="font-medium">How it works</p>
              <p>Your frontend → <strong>/api/chat</strong> (your Vercel proxy) → OpenAI/Kimi API.</p>
              <p className="text-xs mt-1">This solves CORS and keeps your API key secure. You must deploy to Vercel.</p>
            </div>
          </div>

          {/* Presets */}
          <div className="grid grid-cols-2 gap-2">
            {(Object.entries(presets) as [PresetKey, typeof presets[PresetKey]][]).map(([key, p]) => (
              <Button key={key} variant={preset === key ? 'default' : 'outline'} size="sm" onClick={() => handlePresetChange(key)}>
                {p.label}
              </Button>
            ))}
          </div>

          {/* API Key */}
          <div className="space-y-1">
            <label className="text-sm font-medium">API Key</label>
            <Input value={apiKey} onChange={(e) => { setApiKey(e.target.value); setTestResult(null); }} placeholder="sk-..." type="password" />
            <p className="text-xs text-muted-foreground">Your key is stored locally and sent via secure headers to your own proxy.</p>
          </div>

          {/* Base URL */}
          <div className="space-y-1">
            <label className="text-sm font-medium">API Base URL</label>
            <Input value={baseUrl} onChange={(e) => { setBaseUrl(e.target.value); setPreset('custom'); setTestResult(null); }} placeholder="https://api.openai.com/v1" />
          </div>

          {/* Model */}
          <div className="space-y-1">
            <label className="text-sm font-medium">Model</label>
            <Input value={model} onChange={(e) => { setModel(e.target.value); setPreset('custom'); setTestResult(null); }} placeholder="gpt-4o-mini" />
          </div>

          {/* Test Result */}
          {testResult && (
            <div className={`flex gap-2 p-3 rounded-md text-sm ${testResult.ok ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
              {testResult.ok ? <CheckCircle className="w-5 h-5 shrink-0" /> : <AlertCircle className="w-5 h-5 shrink-0" />}
              <div className="whitespace-pre-wrap">{testResult.msg}</div>
            </div>
          )}

          <div className="flex gap-2">
            <Button variant="outline" onClick={handleTest} disabled={!canSave || testing} className="flex-1">
              {testing ? 'Testing...' : 'Test Connection'}
            </Button>
            <Button onClick={handleSave} disabled={!canSave} className="flex-1">Save & Continue</Button>
          </div>
        </CardContent>
      </Card>

      {/* Deployment Guide */}
      <Card>
        <CardHeader><CardTitle className="text-base">Deployment Guide</CardTitle></CardHeader>
        <CardContent className="space-y-3 text-sm">
          <p className="text-muted-foreground">This app requires a backend proxy. Deploy to Vercel (free):</p>
          <ol className="space-y-2 list-decimal list-inside text-muted-foreground">
            <li>Push this code to a GitHub repo</li>
            <li>Go to <a href="https://vercel.com" target="_blank" rel="noreferrer" className="underline text-primary">vercel.com</a> and import the repo</li>
            <li>Vercel auto-detects the <code>api/</code> functions — just click Deploy</li>
            <li>Open your deployed URL and configure your API key here</li>
          </ol>
          <p className="text-xs text-muted-foreground">The proxy only forwards requests — it never stores API keys.</p>
        </CardContent>
      </Card>
    </div>
  );
}
