import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PenLine, MessageSquare, ListChecks } from 'lucide-react';

interface Props { onMode: (mode: 'free' | 'implant' | 'today') => void; onProgress: () => void; }

export default function HomePage({ onMode, onProgress }: Props) {
  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">ECLM Learn</h1>
        <p className="text-muted-foreground">Emergent Construction Learning Model</p>
        <p className="text-sm text-muted-foreground">Usage-Based language acquisition through construction awareness</p>
      </div>

      <div className="grid gap-4">
        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onMode('free')}>
          <CardContent className="p-5 flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"><PenLine className="w-5 h-5 text-primary" /></div>
            <div className="space-y-1">
              <h3 className="font-semibold">Free Expression</h3>
              <p className="text-sm text-muted-foreground">Write about anything. We analyze your construction usage and identify upgrade opportunities.</p>
              <Badge variant="outline" className="text-xs">Discover your gaps</Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onMode('implant')}>
          <CardContent className="p-5 flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"><MessageSquare className="w-5 h-5 text-primary" /></div>
            <div className="space-y-1">
              <h3 className="font-semibold">Construction Implant</h3>
              <p className="text-sm text-muted-foreground">Learn a specific construction through guided dialogue. Try, get feedback, try again.</p>
              <Badge variant="outline" className="text-xs">Guided practice</Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onMode('today')}>
          <CardContent className="p-5 flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"><ListChecks className="w-5 h-5 text-primary" /></div>
            <div className="space-y-1">
              <h3 className="font-semibold">Today&apos;s Iterations</h3>
              <p className="text-sm text-muted-foreground">A curated sequence of varied-context encounters for constructions in your ZPD.</p>
              <Badge variant="outline" className="text-xs">Personalized sequence</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="text-center"><Button variant="outline" onClick={onProgress}>View My Construction Network</Button></div>
    </div>
  );
}
