import { useState, useEffect, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Send, AlertCircle } from 'lucide-react';
import type { DialogueTurn } from '@/types';
import { implantFirstTurn, implantTurn } from '@/engine/llm';
import { constructionMap } from '@/data/constructions';

interface Props { constructionId: string; onBack: () => void; }

export default function ConstructionImplant({ constructionId, onBack }: Props) {
  const c = constructionMap.get(constructionId);
  const [history, setHistory] = useState<DialogueTurn[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [started, setStarted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { scrollRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [history]);

  if (!c) {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="w-4 h-4 mr-2" />Back</Button>
        <p className="text-muted-foreground mt-4">Construction not found.</p>
      </div>
    );
  }

  const start = async () => {
    setLoading(true);
    setError(null);
    try {
      const turn = await implantFirstTurn(c);
      setHistory([turn]);
      setStarted(true);
    } catch (e) {
      const msg = (e as Error).message;
      if (msg.includes('CORS') || msg.includes('Failed to fetch')) {
        setError('Network error: Your browser may be blocking the API request. If using Kimi, check that the API allows browser requests. Try a local proxy or a CORS extension.');
      } else if (msg.includes('401') || msg.includes('403')) {
        setError('Authentication failed: Invalid API key. Please check your API key in Settings.');
      } else if (msg.includes('404')) {
        setError('API endpoint not found. Check your Base URL in Settings.');
      } else {
        setError('API error: ' + msg);
      }
    }
    setLoading(false);
  };

  const send = async () => {
    if (!input.trim() || loading) return;
    const studentTurn: DialogueTurn = { role: 'student', content: input };
    const newHistory = [...history, studentTurn];
    setHistory(newHistory);
    setInput('');
    setLoading(true);
    setError(null);
    try {
      const tutorCount = newHistory.filter((t) => t.role === 'tutor').length;
      const turn = await implantTurn(c, input, newHistory, tutorCount + 1);
      setHistory([...newHistory, turn]);
    } catch (e) {
      const msg = (e as Error).message;
      setHistory(newHistory); // Keep student message even if tutor fails
      if (msg.includes('401') || msg.includes('403')) {
        setError('Authentication failed. Check your API key in Settings.');
      } else {
        setError('Failed to get response: ' + msg);
      }
    }
    setLoading(false);
  };

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-4">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="w-4 h-4" /></Button>
        <div>
          <h2 className="text-lg font-semibold">Construction Implant</h2>
          <p className="text-xs text-muted-foreground">{c.form} — {c.meaning}</p>
        </div>
        <Badge variant="outline" className="ml-auto">{c.cefr}</Badge>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex gap-3 items-start">
          <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div className="text-sm text-red-800">{error}</div>
        </div>
      )}

      {!started ? (
        <Card>
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <h3 className="font-medium">Target: {c.form}</h3>
              <p className="text-sm text-muted-foreground">{c.meaning}</p>
              <p className="text-sm">Level: {c.cefr} | Register: {c.register}</p>
              {c.learnerDefault && <p className="text-sm text-amber-700">Students often use: &quot;{c.learnerDefault}&quot;</p>}
            </div>
            <Button onClick={start} disabled={loading} className="w-full">{loading ? 'Preparing...' : 'Start Dialogue'}</Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card className="max-h-[60vh] overflow-y-auto">
            <CardContent className="p-4 space-y-3">
              {history.map((t, i) => (
                <div key={i} className={`flex ${t.role === 'student' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] rounded-lg px-4 py-2 text-sm ${
                    t.role === 'student'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted'
                  }`}>
                    <p className="whitespace-pre-wrap">{t.content}</p>
                    {t.type && t.role === 'tutor' && (
                      <Badge variant="outline" className="text-xs mt-1">{t.type}</Badge>
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-muted rounded-lg px-4 py-2 text-sm text-muted-foreground">Thinking...</div>
                </div>
              )}
              <div ref={scrollRef} />
            </CardContent>
          </Card>

          <div className="flex gap-2">
            <Textarea value={input} onChange={(e) => setInput(e.target.value)} placeholder="Type your response..." className="min-h-[60px] resize-none" onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} />
            <Button onClick={send} disabled={loading || !input.trim()} className="shrink-0"><Send className="w-4 h-4" /></Button>
          </div>
        </>
      )}
    </div>
  );
}
