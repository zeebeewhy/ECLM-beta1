import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import type { StudentState } from '@/types';
import { constructions } from '@/data/constructions';

interface Props { state: StudentState; onBack: () => void; onImplant: (cid: string) => void; }

const categories: Record<string, string[]> = {
  'Concession/Contrast': ['c-although-clause', 'c-despite-np', 'c-while-admittedly', 'c-however', 'c-but', 'c-on-the-other-hand', 'c-by-contrast', 'c-while-it-is-true'],
  'Cause/Result': ['c-because-clause', 'c-due-to', 'c-as-a-result', 'c-this-leads-to', 'c-so', 'c-cause-result-schema'],
  'Evaluation': ['c-widely-acknowledged', 'c-there-is-no-doubt', 'c-it-is-crucial', 'c-it-is-important', 'c-it-is-worth-noting', 'c-play-a-role'],
  'Opinion': ['c-from-my-perspective', 'c-i-believe', 'c-it-seems-to-me', 'c-i-am-convinced'],
  'Addition': ['c-not-only-but-also', 'c-and', 'c-what-is-more', 'c-also'],
  'Severity': ['c-pressing-concern', 'c-existential-threat', 'c-big-problem', 'c-significant', 'c-substantial', 'c-big'],
};

export default function ProgressPage({ state, onBack, onImplant }: Props) {
  const mastered = constructions.filter((c) => (state.mastery[c.id]?.beta ?? 0) > 0.7).length;
  const total = constructions.length;
  const inProgress = constructions.filter((c) => {
    const m = state.mastery[c.id];
    return m && m.beta > 0 && m.beta <= 0.7;
  }).length;

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="w-4 h-4" /></Button>
        <h2 className="text-lg font-semibold">My Construction Network</h2>
      </div>

      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="flex justify-between text-sm"><span>{Math.round((mastered/total)*100)}% explored</span><span>{mastered}/{total} constructions</span></div>
          <Progress value={(mastered/total)*100} className="h-2" />
          <div className="flex gap-4 text-xs text-muted-foreground">
            <span>{mastered} mastered</span><span>{inProgress} in progress</span><span>{total - mastered - inProgress} untouched</span>
          </div>
        </CardContent>
      </Card>

      {Object.entries(categories).map(([catName, ids]) => {
        const cats = ids.map((id) => constructions.find((c) => c.id === id)!).filter(Boolean);
        return (
          <Card key={catName}>
            <CardHeader className="pb-2"><CardTitle className="text-base">{catName}</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {cats.map((c) => {
                const m = state.mastery[c.id];
                const beta = m?.beta ?? 0;
                const gamma = m?.gamma ?? 0;
                return (
                  <div key={c.id} className="flex items-center justify-between text-sm group cursor-pointer" onClick={() => onImplant(c.id)}>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className={`truncate ${beta > 0.7 ? 'text-green-700 font-medium' : beta > 0 ? 'text-amber-700' : ''}`}>{c.form}</span>
                        {beta > 0.7 && <Badge variant="outline" className="text-xs text-green-600 shrink-0">mastered</Badge>}
                        {beta > 0 && beta <= 0.7 && <Badge variant="outline" className="text-xs text-amber-600 shrink-0">learning</Badge>}
                      </div>
                      <div className="flex gap-3 text-xs text-muted-foreground mt-0.5">
                        <span>beta: {Math.round(beta*100)}%</span>
                        {gamma > 0 && <span>contexts: {gamma}</span>}
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">Practice</Button>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
