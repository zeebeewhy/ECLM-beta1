import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Sparkles, ChevronRight } from 'lucide-react';
import type { ContrastiveAnalysis } from '@/types';
import { contrastiveAnalyze } from '@/engine/llm';
import { constructionMap } from '@/data/constructions';

interface Props { onBack: () => void; onImplant: (cid: string) => void; }

export default function FreeExpression({ onBack, onImplant }: Props) {
  const [text, setText] = useState('');
  const [analysis, setAnalysis] = useState<ContrastiveAnalysis | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    if (!text.trim() || text.trim().split(/\s+/).length < 5) return;
    setLoading(true);
    try {
      const result = await contrastiveAnalyze(text);
      setAnalysis(result);
    } catch (e) {
      alert('Analysis failed: ' + (e as Error).message);
    }
    setLoading(false);
  };

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-4">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="w-4 h-4" /></Button>
        <h2 className="text-lg font-semibold">Free Expression</h2>
      </div>

      {!analysis ? (
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-base">Write freely</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">Write about anything — an opinion, a story, a response to a topic. We&apos;ll analyze your construction usage and find upgrade opportunities.</p>
            <Textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Start writing in English..." className="min-h-[200px]" />
            <div className="flex justify-between items-center">
              <span className="text-xs text-muted-foreground">{text.trim().split(/\s+/).filter(Boolean).length} words</span>
              <Button onClick={handleAnalyze} disabled={text.trim().split(/\s+/).filter(Boolean).length < 5 || loading}>
                <Sparkles className="w-4 h-4 mr-2" />{loading ? 'Analyzing...' : 'Analyze My Writing'}
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          <Card className="bg-muted/50">
            <CardContent className="p-4"><p className="text-sm whitespace-pre-wrap">{text}</p></CardContent>
          </Card>

          <div className="flex items-center gap-2">
            <Badge variant="secondary">Level: {analysis.overallLevel}</Badge>
            <Badge variant="outline">{analysis.constructionsUsed.length} constructions used</Badge>
            <Badge variant="default">{analysis.gaps.length} upgrade opportunities</Badge>
          </div>

          {analysis.constructionsUsed.length > 0 && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base text-green-700">Constructions Used</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {analysis.constructionsUsed.map((u, i) => {
                  const c = constructionMap.get(u.constructionId);
                  return (
                    <div key={i} className="flex items-center gap-2 text-sm">
                      <span className="text-green-600">&#10003;</span>
                      <span className="font-medium">{c?.form || u.constructionId}</span>
                      <span className="text-muted-foreground">— "{u.text}"</span>
                      <Badge variant="outline" className="text-xs ml-auto">{u.quality}</Badge>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          )}

          {analysis.gaps.length > 0 && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base text-amber-700">Upgrade Opportunities</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {analysis.gaps.map((gap, i) => {
                  const c = constructionMap.get(gap.constructionId);
                  return (
                    <div key={i} className="border rounded-md p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm">{c?.form || gap.targetForm}</span>
                        <div className="flex gap-1">
                          {gap.inZPD && <Badge variant="default" className="text-xs">In Your ZPD</Badge>}
                          <Badge variant="outline" className="text-xs">{gap.gapType}</Badge>
                        </div>
                      </div>
                      <div className="text-sm space-y-1">
                        <p><span className="text-muted-foreground">You wrote:</span> <span className="line-through text-red-600">{gap.studentText}</span></p>
                        <p><span className="text-muted-foreground">Upgrade to:</span> <span className="text-green-700 font-medium">{gap.targetForm}</span></p>
                        <p className="text-xs text-muted-foreground italic">"{gap.context}"</p>
                      </div>
                      <Button size="sm" variant="outline" onClick={() => onImplant(gap.constructionId)} className="w-full">
                        <ChevronRight className="w-3 h-3 mr-1" />Learn This Construction
                      </Button>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          )}

          <div className="flex gap-3">
            <Button variant="outline" onClick={() => { setAnalysis(null); setText(''); }} className="flex-1">Write Something New</Button>
          </div>
        </div>
      )}
    </div>
  );
}
