import { useState } from 'react';
import { getLLMConfig } from '@/engine/llm';
import { useStudentStore } from '@/hooks/useStore';
import { Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ApiKeySetup from '@/components/ApiKeySetup';
import HomePage from '@/components/HomePage';
import FreeExpression from '@/components/FreeExpression';
import ConstructionImplant from '@/components/ConstructionImplant';
import ProgressPage from '@/components/ProgressPage';

type View = 'home' | 'free' | 'implant' | 'progress' | 'today' | 'settings';

export default function App() {
  const [hasKey, setHasKey] = useState(() => !!getLLMConfig().apiKey);
  const [view, setView] = useState<View>('home');
  const [implantId, setImplantId] = useState<string | null>(null);
  const { state } = useStudentStore();

  const goHome = () => setView('home');
  const goImplant = (cid: string) => { setImplantId(cid); setView('implant'); };

  if (!hasKey) return <ApiKeySetup onDone={() => setHasKey(true)} />;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={goHome}>
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">E</span>
            </div>
            <span className="font-semibold text-lg">ECLM Learn</span>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setView('settings')}>
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </header>

      <main className="py-6">
        {view === 'home' && <HomePage onMode={(m) => setView(m as View)} onProgress={() => setView('progress')} />}
        {view === 'free' && <FreeExpression onBack={goHome} onImplant={goImplant} />}
        {view === 'implant' && implantId && <ConstructionImplant constructionId={implantId} onBack={goHome} />}
        {view === 'progress' && <ProgressPage state={state} onBack={goHome} onImplant={goImplant} />}
        {view === 'today' && <div className="max-w-2xl mx-auto p-6 text-center">Coming soon: personalized iteration sequences.</div>}
        {view === 'settings' && <ApiKeySetup onDone={goHome} />}
      </main>
    </div>
  );
}
