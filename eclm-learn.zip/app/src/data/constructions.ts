/**
 * Construction Inventory: 50 core academic constructions
 * Organized by functional category with vertical/horizontal links
 */

import type { Construction } from '@/types';

export const constructions: Construction[] = [
  // ===== CONCESSION / CONTRAST =====
  {
    id: 'c-although-clause', form: '[Although/While/Even though] S V, S V',
    forms: ['Although X, Y', 'While X, Y', 'Even though X, Y'], meaning: 'Express concession: acknowledge a counterpoint while maintaining your main argument',
    level: 'meso', cefr: 'B2', domain: ['argumentation', 'academic', 'general'], register: 'academic', isFormulaic: false,
    parents: ['c-concession-schema'], children: ['c-despite-np'], peers: [{ id: 'c-but', relation: 'compete' }, { id: 'c-however', relation: 'intensify' }], learnerDefault: 'but',
  },
  {
    id: 'c-despite-np', form: 'Despite [NP/V-ing], S V',
    forms: ['Despite X, Y', 'In spite of X, Y'], meaning: 'Express concession using noun phrase instead of clause',
    level: 'micro', cefr: 'B2', domain: ['argumentation', 'academic'], register: 'academic', isFormulaic: false,
    parents: ['c-concession-schema'], children: [], peers: [{ id: 'c-although-clause', relation: 'collocate' }], learnerDefault: 'although',
  },
  {
    id: 'c-concession-schema', form: '[Concession marker] [counterpoint], [main point]',
    forms: [], meaning: 'Abstract schema: acknowledge opposition then reaffirm position',
    level: 'macro', cefr: 'C1', domain: ['argumentation'], register: 'academic', isFormulaic: false,
    parents: [], children: ['c-although-clause', 'c-despite-np', 'c-while-admittedly'], peers: [], learnerDefault: 'but...',
  },
  {
    id: 'c-while-admittedly', form: 'While it is true that X, Y',
    forms: ['While it is true that X, Y', 'Admittedly, X. However, Y'], meaning: 'Polite concession: acknowledge validity of opposing view before countering',
    level: 'micro', cefr: 'C1', domain: ['argumentation', 'academic'], register: 'formal', isFormulaic: true,
    parents: ['c-concession-schema'], children: [], peers: [{ id: 'c-although-clause', relation: 'intensify' }], learnerDefault: 'but',
  },
  {
    id: 'c-however', form: 'X. However, Y.',
    forms: ['X. However, Y', 'X. Nevertheless, Y', 'X. Nonetheless, Y'], meaning: 'Introduce a contrasting point after a statement',
    level: 'micro', cefr: 'B1', domain: ['general', 'academic'], register: 'academic', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-but', relation: 'compete' }, { id: 'c-on-the-other-hand', relation: 'collocate' }], learnerDefault: 'but',
  },
  {
    id: 'c-but', form: 'X, but Y',
    forms: ['X, but Y'], meaning: 'Simple contrast (informal)',
    level: 'micro', cefr: 'A2', domain: ['general'], register: 'informal', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-however', relation: 'compete' }, { id: 'c-although-clause', relation: 'compete' }], learnerDefault: '',
  },
  {
    id: 'c-on-the-other-hand', form: 'On the one hand X. On the other hand, Y.',
    forms: ['On the one hand... on the other hand'], meaning: 'Present two sides of an issue in a balanced way',
    level: 'micro', cefr: 'B2', domain: ['argumentation'], register: 'academic', isFormulaic: true,
    parents: [], children: [], peers: [{ id: 'c-however', relation: 'collocate' }], learnerDefault: 'but',
  },
  {
    id: 'c-by-contrast', form: 'By contrast, X / In contrast, X',
    forms: ['By contrast', 'In contrast'], meaning: 'Highlight difference between two things',
    level: 'micro', cefr: 'B2', domain: ['comparison', 'academic'], register: 'academic', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-however', relation: 'collocate' }], learnerDefault: 'but it is different',
  },

  // ===== CAUSE / RESULT =====
  {
    id: 'c-because-clause', form: 'S V because S V',
    forms: ['because', 'since', 'as'], meaning: 'Express reason/cause',
    level: 'micro', cefr: 'A2', domain: ['general'], register: 'neutral', isFormulaic: false,
    parents: ['c-cause-result-schema'], children: [], peers: [{ id: 'c-due-to', relation: 'compete' }], learnerDefault: 'because',
  },
  {
    id: 'c-due-to', form: '[Due to/Owing to/Because of] NP, S V',
    forms: ['Due to X, Y', 'Owing to X, Y', 'Because of X, Y'], meaning: 'Express cause using noun phrase (formal)',
    level: 'micro', cefr: 'B2', domain: ['academic', 'formal'], register: 'formal', isFormulaic: false,
    parents: ['c-cause-result-schema'], children: [], peers: [{ id: 'c-because-clause', relation: 'compete' }], learnerDefault: 'because of',
  },
  {
    id: 'c-as-a-result', form: 'X. As a result, Y. / Consequently, Y.',
    forms: ['As a result', 'Consequently', 'Therefore', 'Thus', 'Hence'], meaning: 'Introduce a consequence or result',
    level: 'micro', cefr: 'B1', domain: ['general', 'academic'], register: 'academic', isFormulaic: false,
    parents: ['c-cause-result-schema'], children: [], peers: [{ id: 'c-so', relation: 'compete' }, { id: 'c-this-leads-to', relation: 'collocate' }], learnerDefault: 'so',
  },
  {
    id: 'c-cause-result-schema', form: '[Cause] → [Result]',
    forms: [], meaning: 'Abstract causal relation schema',
    level: 'macro', cefr: 'C1', domain: ['general'], register: 'academic', isFormulaic: false,
    parents: [], children: ['c-because-clause', 'c-due-to', 'c-as-a-result', 'c-this-leads-to'], peers: [], learnerDefault: '',
  },
  {
    id: 'c-this-leads-to', form: 'This leads to / results in / gives rise to NP',
    forms: ['This leads to X', 'This results in X', 'This gives rise to X'], meaning: 'Express that one thing causes another (nominalized result)',
    level: 'micro', cefr: 'B2', domain: ['academic'], register: 'academic', isFormulaic: true,
    parents: ['c-cause-result-schema'], children: [], peers: [{ id: 'c-as-a-result', relation: 'collocate' }], learnerDefault: 'so this makes',
  },
  {
    id: 'c-so', form: 'X, so Y',
    forms: ['X, so Y'], meaning: 'Simple result (informal)',
    level: 'micro', cefr: 'A2', domain: ['general'], register: 'informal', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-as-a-result', relation: 'compete' }], learnerDefault: '',
  },
  {
    id: 'c-while-it-is-true', form: 'While it is true that X, this does not necessarily mean that Y',
    forms: ['While it is true that X, this does not necessarily mean that Y'], meaning: 'Acknowledge partial truth then deny full implications',
    level: 'micro', cefr: 'C1', domain: ['argumentation', 'academic'], register: 'formal', isFormulaic: true,
    parents: ['c-concession-schema'], children: [], peers: [{ id: 'c-although-clause', relation: 'intensify' }], learnerDefault: 'but that is not true',
  },

  // ===== EVALUATION / JUDGMENT =====
  {
    id: 'c-widely-acknowledged', form: 'It is widely acknowledged that S V',
    forms: ['It is widely acknowledged that', 'It is generally accepted that', 'It is commonly recognized that'], meaning: 'Present a claim as universally accepted (strengthens argument)',
    level: 'micro', cefr: 'C1', domain: ['academic', 'argumentation'], register: 'formal', isFormulaic: true,
    parents: ['c-evaluation-schema'], children: [], peers: [{ id: 'c-there-is-no-doubt', relation: 'collocate' }], learnerDefault: 'everyone knows that',
  },
  {
    id: 'c-there-is-no-doubt', form: 'There is no doubt that S V',
    forms: ['There is no doubt that', 'There is little doubt that'], meaning: 'Express strong certainty',
    level: 'micro', cefr: 'B2', domain: ['academic', 'argumentation'], register: 'formal', isFormulaic: true,
    parents: ['c-evaluation-schema'], children: [], peers: [{ id: 'c-widely-acknowledged', relation: 'collocate' }], learnerDefault: 'I am sure that',
  },
  {
    id: 'c-evaluation-schema', form: 'It is [EVAL-ADJ] that S V',
    forms: [], meaning: 'Abstract evaluation pattern using extraposed subject',
    level: 'macro', cefr: 'C1', domain: ['academic'], register: 'formal', isFormulaic: false,
    parents: [], children: ['c-widely-acknowledged', 'c-there-is-no-doubt', 'c-it-is-crucial', 'c-it-is-worth-noting'], peers: [], learnerDefault: 'I think',
  },
  {
    id: 'c-it-is-crucial', form: 'It is crucial/vital/essential that S V / for NP to V',
    forms: ['It is crucial that', 'It is vital that', 'It is essential that', 'It is imperative that'], meaning: 'Express strong necessity',
    level: 'micro', cefr: 'B2', domain: ['academic', 'argumentation'], register: 'formal', isFormulaic: true,
    parents: ['c-evaluation-schema'], children: [], peers: [{ id: 'c-it-is-important', relation: 'intensify' }], learnerDefault: 'it is very important',
  },
  {
    id: 'c-it-is-important', form: 'It is important to note that S V',
    forms: ['It is important to note that', 'It is worth noting that', 'It should be noted that'], meaning: 'Highlight a point the reader should pay attention to',
    level: 'micro', cefr: 'B2', domain: ['academic'], register: 'academic', isFormulaic: true,
    parents: ['c-evaluation-schema'], children: [], peers: [{ id: 'c-it-is-crucial', relation: 'compete' }], learnerDefault: 'I want to say',
  },
  {
    id: 'c-it-is-worth-noting', form: 'It is worth noting that X',
    forms: ['It is worth noting that', 'It is noteworthy that'], meaning: 'Introduce an interesting or significant point (softer than "important")',
    level: 'micro', cefr: 'C1', domain: ['academic'], register: 'academic', isFormulaic: true,
    parents: ['c-evaluation-schema'], children: [], peers: [{ id: 'c-it-is-important', relation: 'compete' }], learnerDefault: 'it is interesting',
  },
  {
    id: 'c-play-a-role', form: 'X plays a [significant/crucial/vital] role in Y',
    forms: ['plays a significant role in', 'plays a crucial role in', 'plays a vital role in'], meaning: 'Describe the importance of something in a process/situation',
    level: 'micro', cefr: 'B2', domain: ['academic', 'analysis'], register: 'academic', isFormulaic: true,
    parents: [], children: [], peers: [{ id: 'c-it-is-crucial', relation: 'collocate' }], learnerDefault: 'is very important for',
  },

  // ===== OPINION / STANCE =====
  {
    id: 'c-from-my-perspective', form: 'From my perspective, X / In my view, X',
    forms: ['From my perspective', 'In my view', 'In my opinion'], meaning: 'Introduce personal viewpoint (academic register)',
    level: 'micro', cefr: 'B2', domain: ['argumentation', 'general'], register: 'academic', isFormulaic: true,
    parents: [], children: [], peers: [{ id: 'c-i-believe', relation: 'compete' }, { id: 'c-it-seems-to-me', relation: 'collocate' }], learnerDefault: 'I think',
  },
  {
    id: 'c-i-believe', form: 'I believe that S V / I would argue that S V',
    forms: ['I believe that', 'I would argue that', 'I maintain that'], meaning: 'State a strong personal position',
    level: 'micro', cefr: 'B2', domain: ['argumentation'], register: 'academic', isFormulaic: true,
    parents: [], children: [], peers: [{ id: 'c-from-my-perspective', relation: 'compete' }], learnerDefault: 'I think',
  },
  {
    id: 'c-it-seems-to-me', form: 'It seems to me that S V / It appears that S V',
    forms: ['It seems to me that', 'It appears that'], meaning: 'Express a tentative opinion (hedged, polite)',
    level: 'micro', cefr: 'B2', domain: ['argumentation', 'academic'], register: 'academic', isFormulaic: true,
    parents: [], children: [], peers: [{ id: 'c-from-my-perspective', relation: 'collocate' }], learnerDefault: 'I think',
  },
  {
    id: 'c-i-am-convinced', form: 'I am convinced that S V',
    forms: ['I am convinced that', 'I am firmly of the view that'], meaning: 'Express strong conviction',
    level: 'micro', cefr: 'C1', domain: ['argumentation', 'formal'], register: 'formal', isFormulaic: true,
    parents: [], children: [], peers: [{ id: 'c-i-believe', relation: 'intensify' }], learnerDefault: 'I really think',
  },

  // ===== EMPHASIS / INTENSIFICATION =====
  {
    id: 'c-not-only-but-also', form: 'Not only X, but also Y',
    forms: ['Not only X, but also Y'], meaning: 'Add emphasis by presenting two related positive points',
    level: 'micro', cefr: 'B2', domain: ['argumentation', 'academic'], register: 'academic', isFormulaic: true,
    parents: [], children: [], peers: [{ id: 'c-and', relation: 'intensify' }], learnerDefault: 'X and Y',
  },
  {
    id: 'c-and', form: 'X and Y',
    forms: ['X and Y'], meaning: 'Simple addition (neutral)',
    level: 'micro', cefr: 'A1', domain: ['general'], register: 'neutral', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-not-only-but-also', relation: 'compete' }], learnerDefault: '',
  },
  {
    id: 'c-what-is-more', form: 'What is more / Furthermore / Moreover',
    forms: ['What is more', 'Furthermore', 'Moreover', 'In addition'], meaning: 'Add an additional supporting point',
    level: 'micro', cefr: 'B1', domain: ['general', 'academic'], register: 'academic', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-also', relation: 'intensify' }], learnerDefault: 'also',
  },
  {
    id: 'c-also', form: 'X. Also, Y. / X and Y too.',
    forms: ['Also', 'too', 'as well'], meaning: 'Simple addition (informal)',
    level: 'micro', cefr: 'A2', domain: ['general'], register: 'neutral', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-what-is-more', relation: 'compete' }], learnerDefault: '',
  },
  {
    id: 'c-it-is-noteworthy', form: 'It is particularly noteworthy that X',
    forms: ['It is particularly noteworthy that', 'Of particular note is the fact that'], meaning: 'Single out a specific point for special attention',
    level: 'micro', cefr: 'C1', domain: ['academic'], register: 'formal', isFormulaic: true,
    parents: ['c-evaluation-schema'], children: [], peers: [{ id: 'c-it-is-worth-noting', relation: 'intensify' }], learnerDefault: 'it is very important',
  },

  // ===== SUMMARY / CONCLUSION =====
  {
    id: 'c-in-conclusion', form: 'In conclusion / To sum up / In summary',
    forms: ['In conclusion', 'To sum up', 'In summary'], meaning: 'Signal the beginning of a concluding statement',
    level: 'micro', cefr: 'B1', domain: ['general', 'academic'], register: 'academic', isFormulaic: true,
    parents: ['c-discourse-schema'], children: [], peers: [{ id: 'c-taking-everything-into-account', relation: 'intensify' }], learnerDefault: 'so',
  },
  {
    id: 'c-taking-everything-into-account', form: 'Taking everything into account / All things considered',
    forms: ['Taking everything into account', 'All things considered', 'On balance'], meaning: 'Weigh all factors before giving final judgment',
    level: 'micro', cefr: 'C1', domain: ['argumentation', 'academic'], register: 'formal', isFormulaic: true,
    parents: ['c-discourse-schema'], children: [], peers: [{ id: 'c-in-conclusion', relation: 'intensify' }], learnerDefault: 'so',
  },
  {
    id: 'c-discourse-schema', form: '[Discourse marker] [content]',
    forms: [], meaning: 'Abstract discourse organization schema',
    level: 'macro', cefr: 'C1', domain: ['general'], register: 'academic', isFormulaic: false,
    parents: [], children: ['c-in-conclusion', 'c-taking-everything-into-account', 'c-to-begin-with'], peers: [], learnerDefault: '',
  },
  {
    id: 'c-to-begin-with', form: 'To begin with / First and foremost',
    forms: ['To begin with', 'First and foremost', 'Firstly'], meaning: 'Signal the first point in a sequence',
    level: 'micro', cefr: 'B1', domain: ['general', 'academic'], register: 'academic', isFormulaic: true,
    parents: ['c-discourse-schema'], children: [], peers: [{ id: 'c-in-conclusion', relation: 'collocate' }], learnerDefault: 'first',
  },

  // ===== EXAMPLE / ILLUSTRATION =====
  {
    id: 'c-for-instance', form: 'For instance / For example / A case in point is',
    forms: ['For instance', 'For example', 'A case in point is', 'To illustrate'], meaning: 'Introduce an example that supports a claim',
    level: 'micro', cefr: 'B1', domain: ['general', 'academic'], register: 'academic', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-such-as', relation: 'compete' }, { id: 'c-to-take-one-example', relation: 'intensify' }], learnerDefault: 'like',
  },
  {
    id: 'c-such-as', form: 'X, such as Y / X, including Y',
    forms: ['such as', 'including', 'namely'], meaning: 'List examples within a sentence',
    level: 'micro', cefr: 'A2', domain: ['general'], register: 'neutral', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-for-instance', relation: 'compete' }], learnerDefault: 'like',
  },
  {
    id: 'c-to-take-one-example', form: 'To take one example / By way of illustration',
    forms: ['To take one example', 'By way of illustration'], meaning: 'Introduce a specific detailed example',
    level: 'micro', cefr: 'C1', domain: ['academic'], register: 'formal', isFormulaic: true,
    parents: [], children: [], peers: [{ id: 'c-for-instance', relation: 'intensify' }], learnerDefault: 'for example',
  },

  // ===== CONDITION =====
  {
    id: 'c-provided-that', form: 'Provided that S V / As long as S V',
    forms: ['Provided that', 'As long as', 'On condition that'], meaning: 'Express a condition (positive: if this happens, good result follows)',
    level: 'micro', cefr: 'B2', domain: ['argumentation', 'academic'], register: 'academic', isFormulaic: false,
    parents: ['c-condition-schema'], children: [], peers: [{ id: 'c-if', relation: 'intensify' }], learnerDefault: 'if',
  },
  {
    id: 'c-if', form: 'If S V, S V',
    forms: ['If X, Y'], meaning: 'Simple conditional (neutral)',
    level: 'micro', cefr: 'A2', domain: ['general'], register: 'neutral', isFormulaic: false,
    parents: ['c-condition-schema'], children: [], peers: [{ id: 'c-provided-that', relation: 'compete' }], learnerDefault: '',
  },
  {
    id: 'c-condition-schema', form: '[Condition] → [Result]',
    forms: [], meaning: 'Abstract conditional schema',
    level: 'macro', cefr: 'C1', domain: ['general'], register: 'academic', isFormulaic: false,
    parents: [], children: ['c-if', 'c-provided-that'], peers: [], learnerDefault: '',
  },
  {
    id: 'c-unless', form: 'Unless S V, S V',
    forms: ['Unless X, Y'], meaning: 'Negative condition (if not)',
    level: 'micro', cefr: 'B1', domain: ['general'], register: 'academic', isFormulaic: false,
    parents: ['c-condition-schema'], children: [], peers: [{ id: 'c-if-not', relation: 'intensify' }], learnerDefault: 'if not',
  },

  // ===== PRECISION / ACADEMIC VOCABULARY =====
  {
    id: 'c-significant', form: 'a significant [NP] / significantly [Adj/Adv]',
    forms: ['significant', 'significantly'], meaning: 'Large enough to be important (academic alternative to "big/important")',
    level: 'micro', cefr: 'B2', domain: ['academic'], register: 'academic', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-substantial', relation: 'collocate' }, { id: 'c-big', relation: 'compete' }], learnerDefault: 'big',
  },
  {
    id: 'c-substantial', form: 'a substantial [NP] / substantially [V]',
    forms: ['substantial', 'substantially'], meaning: 'Large in amount/degree (academic)',
    level: 'micro', cefr: 'B2', domain: ['academic'], register: 'academic', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-significant', relation: 'collocate' }, { id: 'c-big', relation: 'compete' }], learnerDefault: 'big',
  },
  {
    id: 'c-big', form: 'a big [NP]',
    forms: ['big'], meaning: 'Large (informal)',
    level: 'micro', cefr: 'A1', domain: ['general'], register: 'informal', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-significant', relation: 'compete' }], learnerDefault: '',
  },
  {
    id: 'c-pressing-concern', form: 'a pressing concern / an urgent issue',
    forms: ['pressing concern', 'urgent issue', 'critical matter'], meaning: 'A problem that needs immediate attention (academic severity expression)',
    level: 'micro', cefr: 'B2', domain: ['academic', 'argumentation'], register: 'academic', isFormulaic: true,
    parents: ['c-severity-schema'], children: [], peers: [{ id: 'c-existential-threat', relation: 'intensify' }, { id: 'c-big-problem', relation: 'compete' }], learnerDefault: 'big problem',
  },
  {
    id: 'c-existential-threat', form: 'an existential threat / an existential crisis',
    forms: ['existential threat', 'existential crisis'], meaning: 'A threat to existence itself (maximum severity)',
    level: 'micro', cefr: 'C1', domain: ['academic', 'argumentation'], register: 'formal', isFormulaic: true,
    parents: ['c-severity-schema'], children: [], peers: [{ id: 'c-pressing-concern', relation: 'intensify' }], learnerDefault: 'very big problem',
  },
  {
    id: 'c-big-problem', form: 'a big problem',
    forms: ['big problem'], meaning: 'A problem (informal, vague)',
    level: 'micro', cefr: 'A1', domain: ['general'], register: 'informal', isFormulaic: false,
    parents: ['c-severity-schema'], children: [], peers: [{ id: 'c-pressing-concern', relation: 'compete' }], learnerDefault: '',
  },
  {
    id: 'c-severity-schema', form: '[Severity adj] [NOUN]',
    forms: [], meaning: 'Abstract severity expression schema',
    level: 'macro', cefr: 'C1', domain: ['academic'], register: 'academic', isFormulaic: false,
    parents: [], children: ['c-pressing-concern', 'c-existential-threat', 'c-big-problem'], peers: [], learnerDefault: '',
  },

  // ===== TREND / CHANGE =====
  {
    id: 'c-increasingly', form: 'increasingly [ADJ/ADV]',
    forms: ['increasingly', 'progressively', 'steadily'], meaning: 'Describe a growing trend',
    level: 'micro', cefr: 'B2', domain: ['academic', 'analysis'], register: 'academic', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-more-and-more', relation: 'compete' }], learnerDefault: 'more and more',
  },
  {
    id: 'c-more-and-more', form: 'more and more [ADJ/NOUN]',
    forms: ['more and more'], meaning: 'Growing trend (informal)',
    level: 'micro', cefr: 'A2', domain: ['general'], register: 'informal', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-increasingly', relation: 'compete' }], learnerDefault: '',
  },
  {
    id: 'c-a-growing-number', form: 'a growing number of [NP]',
    forms: ['a growing number of', 'an increasing number of', 'a rising number of'], meaning: 'Describe quantitative growth (academic)',
    level: 'micro', cefr: 'B2', domain: ['academic', 'analysis'], register: 'academic', isFormulaic: true,
    parents: ['c-trend-schema'], children: [], peers: [{ id: 'c-more-and-more-people', relation: 'compete' }], learnerDefault: 'more and more people',
  },
  {
    id: 'c-more-and-more-people', form: 'more and more people / more people are V-ing',
    forms: ['more and more people'], meaning: 'Growing population trend (informal)',
    level: 'micro', cefr: 'A2', domain: ['general'], register: 'informal', isFormulaic: true,
    parents: ['c-trend-schema'], children: [], peers: [{ id: 'c-a-growing-number', relation: 'compete' }], learnerDefault: '',
  },
  {
    id: 'c-trend-schema', form: '[Trend marker] [change]',
    forms: [], meaning: 'Abstract trend expression schema',
    level: 'macro', cefr: 'C1', domain: ['academic'], register: 'academic', isFormulaic: false,
    parents: [], children: ['c-increasingly', 'c-a-growing-number'], peers: [], learnerDefault: '',
  },
  {
    id: 'c-has-the-potential-to', form: 'X has the potential to V',
    forms: ['has the potential to', 'has the capacity to'], meaning: 'Describe future possibility (hedged, academic)',
    level: 'micro', cefr: 'B2', domain: ['academic', 'analysis'], register: 'academic', isFormulaic: true,
    parents: [], children: [], peers: [{ id: 'c-can', relation: 'intensify' }], learnerDefault: 'can',
  },
  {
    id: 'c-can', form: 'X can V',
    forms: ['can'], meaning: 'Ability/possibility (neutral)',
    level: 'micro', cefr: 'A1', domain: ['general'], register: 'neutral', isFormulaic: false,
    parents: [], children: [], peers: [{ id: 'c-has-the-potential-to', relation: 'compete' }], learnerDefault: '',
  },
];

/** Lookup map */
export const constructionMap = new Map(constructions.map((c) => [c.id, c]));

/** Get constructions by level */
export function byLevel(level: 'micro' | 'meso' | 'macro') {
  return constructions.filter((c) => c.level === level);
}

/** Get leaf constructions (no children = most specific) */
export function leafConstructions() {
  return constructions.filter((c) => c.children.length === 0);
}

/** Get a construction's compete peers */
export function competePeers(c: Construction): Construction[] {
  return c.peers.filter((p) => p.relation === 'compete').map((p) => constructionMap.get(p.id)!).filter(Boolean);
}
