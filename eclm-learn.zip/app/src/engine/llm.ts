/**
 * ECLM LLM Engine — calls /api/chat proxy (Vercel Edge Function)
 * No API keys in frontend code. Keys travel via secure headers to same-origin proxy.
 */

import type { ContrastiveAnalysis, DialogueTurn, Construction } from '@/types';
import { constructions, constructionMap } from '@/data/constructions';

// ===== Config: stored in localStorage (user's target API settings) =====

interface LLMConfig {
  apiKey: string;
  baseUrl: string;
  model: string;
}

const DEFAULT_CONFIG: LLMConfig = {
  apiKey: '',
  baseUrl: 'https://api.openai.com/v1',
  model: 'gpt-4o-mini',
};

export const PRESETS: Record<string, { baseUrl: string; model: string; label: string }> = {
  openai: { baseUrl: 'https://api.openai.com/v1', model: 'gpt-4o-mini', label: 'OpenAI' },
  kimi:   { baseUrl: 'https://api.moonshot.cn/v1', model: 'moonshot-v1-8k', label: 'Kimi Code' },
  azure:  { baseUrl: 'https://YOUR_RESOURCE.openai.azure.com/openai/deployments/YOUR_DEPLOYMENT', model: 'gpt-4o', label: 'Azure OpenAI' },
  custom: { baseUrl: '', model: '', label: 'Custom' },
};

function loadConfig(): LLMConfig {
  try {
    const raw = localStorage.getItem('eclm_llm_config');
    if (raw) return { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return { ...DEFAULT_CONFIG };
}

function saveConfig(config: LLMConfig) {
  localStorage.setItem('eclm_llm_config', JSON.stringify(config));
}

let config: LLMConfig = loadConfig();

export function getLLMConfig(): LLMConfig { return { ...config }; }
export function setLLMConfig(newConfig: Partial<LLMConfig>) {
  config = { ...config, ...newConfig };
  saveConfig(config);
}
export function getPresets() { return PRESETS; }

// ===== Proxy API Call =====
// All requests go to /api/chat (same-origin, no CORS issues)
// Target API config travels in headers, never in URL or body

export class LLMError extends Error {
  status: number;
  detail: string;
  constructor(status: number, detail: string) {
    super(status === 0 ? `Network error: ${detail}` : `API error ${status}: ${detail}`);
    this.status = status;
    this.detail = detail;
  }
}

function diagnoseError(err: unknown): LLMError {
  if (err instanceof LLMError) return err;
  const e = err as Record<string, unknown>;
  if (e.status === 401 || e.status === 403) {
    return new LLMError(401, 'Authentication failed. Check your API key is correct and has not expired.');
  }
  if (e.status === 429) return new LLMError(429, 'Rate limited. Too many requests.');
  if (e.message && typeof e.message === 'string') {
    return new LLMError(e.status as number || 0, e.message);
  }
  return new LLMError(0, String(err));
}

async function callProxy(messages: Array<{ role: string; content: string }>, temperature = 0.7): Promise<string> {
  if (!config.apiKey) throw new LLMError(0, 'No API key configured. Go to Settings.');
  if (!config.baseUrl) throw new LLMError(0, 'No API base URL configured.');
  if (!config.model) throw new LLMError(0, 'No model configured.');

  const body = { messages, temperature, max_tokens: 2000, stream: false };

  let res: Response;
  try {
    res = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': config.apiKey,
        'x-base-url': config.baseUrl,
        'x-model': config.model,
      },
      body: JSON.stringify(body),
    });
  } catch (fetchErr) {
    throw diagnoseError(fetchErr);
  }

  let data: Record<string, unknown>;
  try {
    data = await res.json();
  } catch {
    throw new LLMError(res.status, 'Invalid JSON response from proxy');
  }

  if (!res.ok) {
    const detail = (data.error as Record<string, string>)?.message
      || (data.error as string)
      || JSON.stringify(data);
    throw new LLMError(res.status, detail);
  }

  const content = (data.choices as Array<{ message: { content: string } }>)?.[0]?.message?.content;
  if (!content) {
    throw new LLMError(0, `Unexpected response: ${JSON.stringify(data).slice(0, 200)}`);
  }
  return content;
}

/** Quick connectivity test */
export async function callLLMTest(): Promise<string> {
  const response = await callProxy([
    { role: 'user', content: 'Say "ECLM API test OK" and nothing else.' },
  ], 0.1);
  return response.trim();
}

// ===== Construction Analysis Prompts =====

const CONSTRUCTION_LIST = constructions.map((c) =>
  `- ${c.id}: "${c.form}" — ${c.meaning} [${c.cefr}]`
).join('\n');

// ===== Contrastive Analysis =====

export async function contrastiveAnalyze(studentText: string, _topic?: string): Promise<ContrastiveAnalysis> {
  const systemPrompt = `You are an expert academic writing analyst. Analyze student writing using the "construction" framework.

Available constructions:
${CONSTRUCTION_LIST}

Analyze and return JSON:
{
  "constructionsUsed": [{ "constructionId": "c-although-clause", "text": "the actual text", "quality": "correct" }],
  "gaps": [{ "constructionId": "c-pressing-concern", "studentText": "big problem", "targetForm": "pressing concern", "gapType": "suboptimal", "context": "full sentence", "inZPD": true }],
  "overallLevel": "B1-B2",
  "suggestedFocus": ["c-pressing-concern"]
}

gapType: "missing"|"suboptimal"|"upgrade_opportunity". inZPD: true if student seems ready. Only meaningful gaps.`;

  try {
    const response = await callProxy([
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `Student wrote:\n"""\n${studentText}\n"""\n\nAnalyze.` },
    ], 0.3);

    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (jsonMatch) return JSON.parse(jsonMatch[0]) as ContrastiveAnalysis;
    throw new Error('No JSON found');
  } catch (err) {
    throw diagnoseError(err);
  }
}

// ===== Construction Implantation =====

export async function implantTurn(
  construction: Construction,
  studentMessage: string,
  history: DialogueTurn[],
  turn: number,
): Promise<DialogueTurn> {
  const competeForms = construction.peers
    .filter((p) => p.relation === 'compete')
    .map((p) => constructionMap.get(p.id)?.form)
    .filter(Boolean);

  const systemPrompt = `You are an expert English tutor using "construction implantation". Help the student acquire: "${construction.form}" (${construction.meaning}).

Key principles:
1. NEVER just give the answer. Guide the student to discover it.
2. Use examples from different contexts.
3. After examples, ask the student to try.
4. If they succeed, celebrate and ask for variation. If struggling, give a hint.
5. Keep responses SHORT (2-3 sentences max).
6. This is turn ${turn}. Adapt: Turn 1-2 = introduce + ask to try; Turn 3+ = push variation or simplify.

Student often uses "${construction.learnerDefault}" instead.
${competeForms.length > 0 ? `Related forms: ${competeForms.join(', ')}` : ''}

Respond as tutor. Be encouraging and concise.`;

  const msgs: Array<{ role: string; content: string }> = [{ role: 'system', content: systemPrompt }];
  for (const h of history) msgs.push({ role: h.role === 'tutor' ? 'assistant' : 'user', content: h.content });
  msgs.push({ role: 'user', content: studentMessage });

  try {
    const content = await callProxy(msgs, 0.8);
    return { role: 'tutor', content, type: 'prompt', targetConstruction: construction.id };
  } catch (err) {
    throw diagnoseError(err);
  }
}

export async function implantFirstTurn(construction: Construction): Promise<DialogueTurn> {
  const systemPrompt = `You are introducing an academic construction to a student. Construction: "${construction.form}" — ${construction.meaning}.

Your first message should:
1. Briefly explain when/why this is useful (1 sentence)
2. Give ONE clear example
3. Ask the student to try

Keep to 2-3 sentences. Be warm. Student currently uses "${construction.learnerDefault}" — mention this as a good upgrade.`;

  try {
    const content = await callProxy([{ role: 'system', content: systemPrompt }], 0.8);
    return { role: 'tutor', content, type: 'explanation', targetConstruction: construction.id };
  } catch (err) {
    throw diagnoseError(err);
  }
}
