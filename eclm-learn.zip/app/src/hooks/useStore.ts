import { useState, useCallback, useEffect } from 'react';
import type { StudentState, Mastery3D, AffectiveState, EncounterRecord } from '@/types';
import { constructions } from '@/data/constructions';

const STORAGE_KEY = 'eclm_state_v2';

function initMastery(): Record<string, Mastery3D> {
  const m: Record<string, Mastery3D> = {};
  for (const c of constructions) {
    m[c.id] = { alpha: 0.05, beta: 0, gamma: 0, lastEncounter: 0, encounterCount: 0, contextsUsed: [] };
  }
  return m;
}

function initAffect(): AffectiveState {
  return { engagement: 0.7, confusion: 0.2, frustration: 0.1, boredom: 0.1, dominant: 'learning' };
}

function createFresh(): StudentState {
  return { mastery: initMastery(), affect: initAffect(), history: [], currentFocus: null };
}

function loadState(): StudentState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw) as StudentState;
  } catch { /* ignore */ }
  return null;
}

export function useStudentStore() {
  const [state, setState] = useState<StudentState>(() => loadState() ?? createFresh());

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }, [state]);

  const recordEncounter = useCallback((rec: EncounterRecord) => {
    setState((s) => {
      const mastery = { ...s.mastery };
      const m = { ...mastery[rec.constructionId] };
      m.lastEncounter = rec.timestamp;
      m.encounterCount += 1;
      m.alpha = Math.min(0.95, m.alpha + rec.deltaAlpha);
      m.beta = Math.min(0.95, m.beta + rec.deltaBeta);
      if (!m.contextsUsed.includes(rec.contextId)) {
        m.contextsUsed = [...m.contextsUsed, rec.contextId];
        m.gamma = m.contextsUsed.length;
      }
      mastery[rec.constructionId] = m;
      return { ...s, mastery, history: [...s.history, rec] };
    });
  }, []);

  const updateAffect = useCallback((affect: AffectiveState) => {
    setState((s) => ({ ...s, affect }));
  }, []);

  const setFocus = useCallback((cid: string | null) => {
    setState((s) => ({ ...s, currentFocus: cid }));
  }, []);

  const reset = useCallback(() => { setState(createFresh()); }, []);

  return { state, recordEncounter, updateAffect, setFocus, reset };
}
