/**
 * Vercel Edge Function: LLM API Proxy
 * Forwards chat completion requests to any OpenAI-compatible API.
 * Solves CORS + keeps API keys out of frontend code.
 */

export const config = { runtime: 'edge' };

// CORS headers for browser requests
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, x-api-key, x-base-url, x-model',
};

export default async function handler(request: Request): Promise<Response> {
  // Handle CORS preflight
  if (request.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  try {
    // Read target API config from request headers
    const apiKey = request.headers.get('x-api-key');
    const baseUrl = request.headers.get('x-base-url');
    const model = request.headers.get('x-model');

    if (!apiKey || !baseUrl || !model) {
      return new Response(
        JSON.stringify({ error: 'Missing headers: x-api-key, x-base-url, x-model' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    // Read request body from frontend
    const body = await request.json();

    // Build target URL
    const url = baseUrl.endsWith('/chat/completions')
      ? baseUrl
      : `${baseUrl.replace(/\/$/, '')}/chat/completions`;

    // Forward to actual API
    const apiResponse = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ ...body, model }),
    });

    // Read response body
    const responseBody = await apiResponse.text();

    // Return with CORS headers
    return new Response(responseBody, {
      status: apiResponse.status,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
      },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}
